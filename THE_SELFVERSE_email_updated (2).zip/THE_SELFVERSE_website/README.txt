THE SELFVERSE - Netlify deployment

1. Create/sign in to a Netlify account.
2. Open Netlify Drop.
3. Upload the THE_SELFVERSE_website folder (or unzip this package first).
4. Netlify will publish the site and give you a netlify.app URL.
5. Open that URL on your phone.

IMPORTANT:
The current counsellor appointments use browser localStorage. This means appointments submitted by a customer on their phone will NOT automatically appear on a counsellor's different phone. To make appointments truly shared online, the site needs a cloud database/backend (for example Supabase or Firebase) and the dashboard should be changed to read/write that shared database.

The current private portal password in the HTML is SELFVERSE2026. This client-side password is not suitable for real security; a production portal should use server-side authentication.
